# Boundary validation evidence

Application v3.0.2 · Frozen commit 7f891c75fe82b7aff309e0e6d2d7c27117a5470d · Reviewed 18 October 2026.

Completed local results: 68 automated tests, 57 browser checks, 257 dossier cases, 144 scouting settings, 90 team scenarios and 257 forced-player requests. Successful plans were independently validated. Raw archive reconciliation compared 3,393,048 fields across 1,455,366 deliveries with zero ingestion mismatches.

Keep these units separate. They are not a single accuracy percentage or proof of professional tactical usefulness. Official source sampling has 194 fields: 188 matches, five T20I coverage gaps and one unresolved conflicting figure. Full current squad and career completeness are not certified. Hosted rebuild and live provider quality remain unverified.

data/ contains machine-readable results and the model/role studies. logs/ contains the completed regression log. browser/ describes the browser checks and screenshot provenance. examples/ contains a reproducible MI-without-Bumrah scenario and scoped scouting rows. docs/ preserves the detailed audit and source description.

Reproduce from the supplied source ZIP using its user guide and tools. Raw verification requires the exact five archives identified in data/audit.json; those large source archives are not redistributed in this submission. Processed data is included in the source ZIP.
